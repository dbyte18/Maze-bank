const form = document.getElementById("form-evento");
const lista = document.getElementById("lista-eventos");
const filtro = document.getElementById("filtro");
const mensaje = document.getElementById("mensaje");

let eventos = JSON.parse(localStorage.getItem("eventos") || "[]");

function guardar() {
  localStorage.setItem("eventos", JSON.stringify(eventos));
}

function avisar(texto, tipo) {
  mensaje.textContent = texto;
  mensaje.className = "mensaje " + tipo;
  mensaje.hidden = false;
  setTimeout(() => (mensaje.hidden = true), 2500);
}

function formatoFecha(iso) {
  const [a, m, d] = iso.split("-").map(Number);
  return new Date(a, m - 1, d).toLocaleDateString("es-CO", {
    weekday: "long", day: "numeric", month: "long", year: "numeric",
  });
}

function formatoPrecio(n) {
  return n > 0 ? "$" + n.toLocaleString("es-CO") + " COP" : "Gratis";
}

function render() {
  const cat = filtro.value;
  const visibles = eventos
    .filter(e => !cat || e.categoria === cat)
    .sort((a, b) => a.fecha.localeCompare(b.fecha));

  lista.innerHTML = "";
  if (visibles.length === 0) {
    lista.innerHTML = "<p>No hay eventos todavía. Agrega el primero arriba.</p>";
    return;
  }

  visibles.forEach(e => {
    const card = document.createElement("article");
    card.className = "evento";
    card.innerHTML = `
      <p class="fecha">${formatoFecha(e.fecha)}</p>
      <h3></h3>
      <p class="lugar"></p>
      <p class="categoria">${e.categoria}</p>
      <p class="precio">${formatoPrecio(e.precio)}</p>
      <button class="eliminar" data-id="${e.id}">Eliminar</button>
    `;
    card.querySelector("h3").textContent = e.nombre;
    card.querySelector(".lugar").textContent = e.lugar;
    lista.appendChild(card);
  });
}

form.addEventListener("submit", ev => {
  ev.preventDefault();
  eventos.push({
    id: Date.now(),
    nombre: form.nombre.value.trim(),
    fecha: form.fecha.value,
    lugar: form.lugar.value.trim(),
    categoria: form.categoria.value,
    precio: Number(form.precio.value) || 0,
  });
  guardar();
  form.reset();
  render();
  avisar("Evento guardado.", "exito");
});

lista.addEventListener("click", ev => {
  const btn = ev.target.closest("button.eliminar");
  if (!btn) return;
  eventos = eventos.filter(e => e.id !== Number(btn.dataset.id));
  guardar();
  render();
});

filtro.addEventListener("change", render);
render();
