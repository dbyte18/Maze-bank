//declarar las variables de los objetos que se van a manipular
const nro1 = document.getElementById("nro1");
const nro2 = document.getElementById("nro2");
const lblResultado = document.getElementById("lblResultado");

function operaciones(operador) {
    //validar que los numeros esten (el value es un string, por eso se compara con "")
    if (nro1.value === "" || nro2.value === "") {
        lblResultado.textContent = "Concentradito, son 2 numeros";
        return;
    }

    const a = Number(nro1.value);
    const b = Number(nro2.value);

    switch (operador) {
        case "+":
            lblResultado.textContent = a + b;
            break;
        case "-":
            lblResultado.textContent = a - b;
            break;
        case "*":
            lblResultado.textContent = a * b;
            break;
        case "/":
            if (b === 0) {
                lblResultado.textContent = "No se puede dividir entre 0";
            } else {
                lblResultado.textContent = a / b;
            }
            break;
    }
}

function limpiar() {
    nro1.value = "";
    nro2.value = "";
    lblResultado.textContent = "00";
}
